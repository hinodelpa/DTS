angular.module('timeattendance.controllers', [])
 



  .controller('ShiftCtrl', function($ionicLoading, $compile, $filter, $cordovaGeolocation, $timeout, $ionicHistory, $ionicLoading, $rootScope, $scope, $state, AuthenticationService, Main) {

    if (Main.getSession("token") == null || Main.getSession("token") == undefined) {
      $state.go("login");
    }

    $state.go("app.shift");
    
  })


  .controller('AddShiftCtrl', function($ionicLoading, $compile, $filter, $cordovaGeolocation, $timeout, $ionicHistory, $ionicLoading, $rootScope, $scope, $state, AuthenticationService, Main) {

    if (Main.getSession("token") == null || Main.getSession("token") == undefined) {
      $state.go("login");
    }

    $state.go("app.shift");
    
  })



 
